#include "grid.h"

void launch_compute_jacobi_hip(double * phi_new_dev, double * phi_old_dev, double * rho_dev, grid_t * g_dev, int nx, int ny );

