#include "field.h"

void compute_jacobi(field_t * phi_new, field_t * phi_old, field_t * rho, int nFields,grid_t * g);